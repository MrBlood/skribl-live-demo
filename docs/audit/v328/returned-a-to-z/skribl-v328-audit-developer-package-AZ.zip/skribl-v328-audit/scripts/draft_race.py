import os,sys,tempfile,json,threading,concurrent.futures,traceback
root=os.environ.get("SKRIBL_SOURCE", "/tmp/skribl-audit/skribl-v328-source");os.chdir(root);sys.path.insert(0,root)
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
import skribl,skribl.models,skribl.drafts as drafts
D=tempfile.TemporaryDirectory(prefix='skribl_draftrace_')
a=Flask('race');a.config.update(SECRET_KEY='audit',SQLALCHEMY_DATABASE_URI='sqlite:///'+D.name+'/data.db',SQLALCHEMY_TRACK_MODIFICATIONS=False,SQLALCHEMY_ENGINE_OPTIONS={'connect_args':{'timeout':3}})
db=SQLAlchemy();db.init_app(a)
skribl.init_skribl(a,session=lambda:db.session,current_user_id=lambda:'alice',csrf=False)
skribl.models.attach_to_metadata(db.metadata)
@a.after_request
def commit(resp):
 if resp.status_code<500:db.session.commit()
 return resp
@a.teardown_request
def reset(exc):db.session.rollback()
with a.app_context():db.create_all()
p={'kind':'pad','title':'Original','payload':{'frames':[{'strokes':[],'strokeGroups':[],'background':{'color':'#101418'}}]}}
orig=drafts._instant
obs=[]
for k in range(3):
 c=a.test_client();init=c.post('/api/drafts',json=p)
 did=init.json['id'];updated=init.json['updatedAt']
 barrier=threading.Barrier(2,timeout=5)
 local=threading.local()
 def pause(v):
  if not getattr(local,'once',False):
   local.once=True
   try:barrier.wait()
   except threading.BrokenBarrierError:pass
  return orig(v)
 drafts._instant=pause
 def put(n):
  try:
   with a.test_client() as client:
    r=client.put('/api/drafts/'+did,json={**p,'title':'Thread '+str(n),'baseUpdatedAt':updated})
    return (r.status_code,r.json.get('error') if r.is_json else '')
  except Exception as e:return ('EXCEPTION',repr(e))
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
  pair=list(executor.map(put,[1,2]))
 drafts._instant=orig
 end=c.get('/api/drafts/'+did)
 record={'run':k+1,'outcomes':pair,'final':end.json.get('title') if end.is_json else None}
 obs.append(record);print(record)
out=os.environ.get('SKRIBL_AUDIT_OUTPUT', os.path.abspath('draft-concurrency-probe.json'))
os.makedirs(os.path.dirname(out), exist_ok=True)
with open(out,'w') as f:json.dump({'note':'Independent stress probe with controlled overlap of two conditional updates; artificial scheduling, SQLite','runs':obs},f,indent=2)
D.cleanup()
