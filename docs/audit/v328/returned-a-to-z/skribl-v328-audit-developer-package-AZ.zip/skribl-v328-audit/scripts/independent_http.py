"""Independent audit probes, not bundled with Skribl v328. Uses disposable SQLite."""
import os,sys,tempfile,json, traceback
root=os.environ.get("SKRIBL_SOURCE", "/tmp/skribl-audit/skribl-v328-source")
os.chdir(root)
sys.path.insert(0,root)
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
import skribl
import skribl.models

out=os.environ.get('SKRIBL_AUDIT_OUTPUT', os.path.abspath('independent-api-results.json'))
os.makedirs(os.path.dirname(out), exist_ok=True)
d=tempfile.TemporaryDirectory(prefix='skribl_audit_api_')
a=Flask('audit')
a.config.update(SECRET_KEY='audit-only-dedicated',SQLALCHEMY_DATABASE_URI='sqlite:///'+d.name+'/db.sqlite',SQLALCHEMY_TRACK_MODIFICATIONS=False)
db=SQLAlchemy();db.init_app(a)
actor=['alice']
skribl.init_skribl(a,session=lambda:db.session, current_user_id=lambda:actor[0],csrf=False,index_route=True)
skribl.models.attach_to_metadata(db.metadata)
@a.after_request
def commit(response):
 if response.status_code < 500:db.session.commit()
 return response
@a.teardown_request
def rollback(_):db.session.rollback()
with a.app_context():db.create_all()
client=a.test_client()
results=[]
def ck(test,cond,status=None,detail=''):
 results.append({'test':test,'pass':bool(cond),'status':status,'detail':str(detail)[:160]})
 print(('PASS' if cond else 'FAIL'),test,status,detail)

def req(method,path,**kwargs):
 return client.open(path,method=method,**kwargs)

def payload(title,visibility='public'):
 return {'frames':[{'strokes':[],'strokeGroups':[], 'background':{'color':'#101418'}}], 'title':title,'caption':'Audit note','visibility':visibility}

try:
 r=req('GET','/api/drafts');ck('signed-in draft list starts empty',r.status_code==200 and r.json.get('items')==[],r.status_code)
 r=req('POST','/api/skribls',json=payload('Audit alpha public')); pub=r.json.get('id') if r.is_json else None
 ck('create public post returns id',r.status_code==201 and bool(pub),r.status_code)
 r=req('GET','/api/skribls/'+pub); ck('public post is retrievable after commit',r.status_code==200,r.status_code)
 actor[0]=None
 r=req('GET','/api/skribls');ck('anonymous sees public item',r.status_code==200 and any(x['id']==pub for x in r.json['items']),r.status_code)
 actor[0]='alice'
 r=req('POST','/api/skribls',json=payload('Audit hidden unlisted','unlisted')); hidden=r.json.get('id') if r.is_json else None
 ck('create unlisted post',r.status_code==201 and bool(hidden),r.status_code)
 actor[0]=None
 r=req('GET','/api/skribls');ck('anonymous public listing omits unlisted',r.status_code==200 and all(x['id']!=hidden for x in r.json['items']),r.status_code)
 r=req('GET','/api/skribls/'+hidden);ck('unlisted link is accessible as designed',r.status_code==200,r.status_code)
 actor[0]='alice'
 r=req('GET','/api/skribls?user_id=alice');ck('owner listing includes unlisted',r.status_code==200 and any(x['id']==hidden for x in r.json['items']),r.status_code)
 actor[0]='bob'
 r=req('GET','/api/skribls?user_id=alice');ck('other signed-in user cannot list unlisted',r.status_code==200 and all(x['id']!=hidden for x in r.json['items']),r.status_code)
 r=req('PATCH','/api/skribls/'+hidden,json={'visibility':'private'});ck('other user cannot change visibility',r.status_code==404,r.status_code)
 actor[0]='alice'
 r=req('PATCH','/api/skribls/'+hidden,json={'visibility':'private'});ck('owner can mark post private',r.status_code==200,r.status_code)
 actor[0]='bob';r=req('GET','/api/skribls/'+hidden);ck('other viewer cannot read private post',r.status_code==404,r.status_code)
 actor[0]='alice';r=req('GET','/api/skribls/'+hidden);ck('owner can read private post',r.status_code==200,r.status_code)
 r=req('GET','/api/skribls?q=Audit%20alpha');ck('search matches title',r.status_code==200 and any(x['id']==pub for x in r.json['items']),r.status_code)
 r=req('GET','/api/skribls?q=%25');ck('search handles literal percent with no crash',r.status_code==200,r.status_code)
 r=req('GET','/api/skribls?cursor=not-a-valid-cursor');ck('invalid cursor refuses cleanly',r.status_code==400,r.status_code)
 r=req('GET','/api/skribls?limit=9999999999999999999999999999');ck('huge requested limit safely bounded',r.status_code==200,r.status_code)
 r=req('GET','/api/drafts');ck('drafts list still empty',r.status_code==200 and r.json.get('items')==[],r.status_code)
 dbody={'kind':'pad','title':'Edited draft','payload':payload('Scratch')}
 r=req('POST','/api/drafts',json=dbody); draft=r.json.get('id') if r.is_json else None
 ck('draft created',r.status_code==201 and bool(draft),r.status_code)
 base=r.json.get('updatedAt') if r.is_json else None
 r=req('GET','/api/drafts/'+draft);ck('draft persists and carries payload',r.status_code==200 and r.json.get('payload',{}).get('title')=='Scratch',r.status_code)
 update=dict(dbody,title='Edited draft V2',baseUpdatedAt=base)
 r=req('PUT','/api/drafts/'+draft,json=update)
 ck('draft conditional update succeeds',r.status_code==200 and r.json['title']=='Edited draft V2',r.status_code)
 r=req('PUT','/api/drafts/'+draft,json=update)
 ck('stale draft update returns conflict',r.status_code==409 and r.json.get('conflict') is True,r.status_code)
 actor[0]='bob'
 r=req('GET','/api/drafts/'+draft);ck('other user cannot read private draft',r.status_code==404,r.status_code)
 r=req('DELETE','/api/drafts/'+draft);ck('other user cannot delete private draft',r.status_code==404,r.status_code)
 actor[0]='alice';r=req('DELETE','/api/drafts/'+draft);ck('owner can delete draft',r.status_code==204,r.status_code)
 r=req('GET','/api/drafts/'+draft);ck('deleted draft stays absent',r.status_code==404,r.status_code)
 r=req('DELETE','/api/skribls/'+pub);ck('owner can delete public post',r.status_code==204,r.status_code)
 r=req('GET','/api/skribls/'+pub);ck('deleted post stays absent',r.status_code==404,r.status_code)
 # malformed submissions must not poison remaining operations
 r=req('POST','/api/skribls',json={'frames':'bad'});ck('invalid submission is rejected, not server error',r.status_code==400,r.status_code)
 r=req('POST','/api/skribls',json=payload('After invalid'));ck('valid creation works after invalid request',r.status_code==201,r.status_code)
 # idempotency scope and changed body
 headers={'Idempotency-Key':'audit-unique-key-77'}
 r1=req('POST','/api/skribls',json=payload('Safe retry'),headers=headers)
 r2=req('POST','/api/skribls',json=payload('Safe retry'),headers=headers)
 ck('idempotent retry uses same post',r1.status_code==201 and r2.status_code==200 and r1.json['id']==r2.json['id'],f'{r1.status_code}/{r2.status_code}')
 r=req('POST','/api/skribls',json=payload('Conflicting retry'),headers=headers)
 ck('idempotency key refuses different payload',r.status_code==409,r.status_code)
except Exception as e:
 print('EXCEPTION',type(e).__name__,str(e));traceback.print_exc(); results.append({'test':'EXECUTION EXCEPTION','pass':False,'detail':type(e).__name__+': '+str(e)})
finally:
 with open(out,'w') as f: json.dump({'source':'independent newly authored tests','total':len(results),'passed':sum(x['pass'] for x in results),'cases':results},f,indent=2)
 print('SUMMARY',sum(x['pass'] for x in results),'/',len(results), 'saved',out)
 d.cleanup()
